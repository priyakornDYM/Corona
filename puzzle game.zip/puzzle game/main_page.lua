

textObject = display.newText( "Hello World2!", 70, 40, native.systemFont, 36 )
textObject:setTextColor( 255,255,255)

